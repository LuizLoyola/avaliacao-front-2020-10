export class Reminder {
  id: number;
  title: string;
  priority: string;
  content: string;
}
